Put these in your kingtomato folder anywhere. you can make
a folder, as i have, called paintball inside the kingtomato
folder and put them there if you want. The hud is optional,
but i just like it. Shows you kills, deaths, and your ratio
of headshots to kills.

Then put the wavs file in \tribes\base\voices. Voila!

-kingtomato