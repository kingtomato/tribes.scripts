Put the .vol into your dynamix\tribes\base directory. Voila, red force fields.

-KingTomato